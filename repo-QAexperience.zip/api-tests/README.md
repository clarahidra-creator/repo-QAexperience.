
# API Tests (Postman)

Import `postman_collection.json` in Postman.  
Set variables:
- `baseUrl` – API base
- `email` / `password` – test creds
- `token` – set after login to call protected endpoints
